package Assignment;

public class Ques5 {
	private String MovieName;
	private String HeroName;
	private String HeroinName;
	private int year;
	public String getMovieName() {
		return MovieName;
	}
	public void setMovieName(String movieName) {
		this.MovieName = movieName;
	}
	public String getHeroName() {
		return HeroName;
	}
	public void setHeroName(String heroName) {
		this.HeroName = heroName;
	}
	public String getHeroinName() {
		return HeroinName;
	}
	public void setHeroinName(String heroinName) {
		this.HeroinName = heroinName;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public Ques5() {
	}
	
}
